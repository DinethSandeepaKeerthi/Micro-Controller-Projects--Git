#include <Keypad.h>
const byte ROWS = 4; // Four rows
const byte COLS = 3; // Three columns

// Define the Keymap
char keys[ROWS][COLS] = {
  {'1', '2', '3'},
  {'4', '5', '6'},
  {'7', '8', '9'},
  {'*', '0', '#'}
};
byte rowPins[ROWS] = { A3, A4, A5, 13 } ; // Connect keypad ROW0, ROW1, ROW2 and ROW3 to these Arduino pins.
byte colPins[COLS] = { A0, A1, A2 }; // Connect keypad COL0, COL1 and COL2 to these Arduino pins.

char key, action;
Keypad kpd = Keypad( makeKeymap(keys), rowPins, colPins, ROWS, COLS );

int Number;

int Tall, Short, Total;




const int motorpin = 6;


#include <LiquidCrystal.h>

#include <HCSR04.h>
HCSR04 hc(10, 9);

const int rs = 12, en = 11, d4 = 5, d5 = 4, d6 = 3, d7 = 2;
LiquidCrystal lcd(rs, en, d4, d5, d6, d7);
boolean result = false;





void setup() {
  Serial.begin(9600);
  lcd.begin(20, 4);

  Serial.print("Starting...!");
  lcd.print("Starting...!");
  delay(1000);
  lcd.clear();

  lcd.print("Enter Number of products");

}
void loop() {



  key = kpd.getKey(); //storing pressed key value in a char

  if (key != NO_KEY) {
    DetectButtons();
    

  }
  if (result == true) {
    lcd.clear();
    motoron();
    process();
    motoroff();
    delay(1000);

    lcd.print("Enter Number of products");
  }


}

void process() {
  int i = 0 ;
  while ( i < Number) {
    int ab =  hc.dist();

    if ( ab < 50 ) {

      Serial.println("Tall");
      Tall++;
      Total++;
      i++;
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Total    :");
      lcd.setCursor(10, 0);
      lcd.print(Number);
      lcd.setCursor(0, 1);
      lcd.print("Ongoing:");
      lcd.setCursor(9, 1);
      lcd.print(i);
      lcd.setCursor(12, 1);
      lcd.print("Tall");

      lcd.setCursor(0, 2);

      lcd.print("Tall     :");
      lcd.setCursor(10, 2);
      lcd.print(Tall);
      lcd.setCursor(0, 3);
      lcd.print("Short    :");
      lcd.setCursor(10, 3);
      lcd.print(Short);
      delay(1000);
      lcd.clear();
    }

    if (50 < ab && ab < 75 ) {
      Serial.println("Short");
      Short++;
      Total++;
      i++;
      lcd.clear();
      lcd.setCursor(0, 0);
      lcd.print("Total    :");
      lcd.setCursor(10, 0);
      lcd.print(Number);
      lcd.setCursor(0, 1);
      lcd.print("Ongoing  :");
      lcd.setCursor(9, 1);
      lcd.print(i);
      lcd.setCursor(12, 1);
      lcd.print("Tall");
      lcd.setCursor(0, 2);

      lcd.print("Tall     :");
      lcd.setCursor(10, 2);
      lcd.print(Tall);
      lcd.setCursor(0, 3);
      lcd.print("Short    :");
      lcd.setCursor(10, 3);
      lcd.print(Short);
      delay(1000);
      lcd.clear();
    }
    else {
      lcd.setCursor(0, 0);
      lcd.print("Total    :");
      lcd.setCursor(10, 0);
      lcd.print(Number);
      lcd.setCursor(0, 1);
      lcd.print("Ongoing  :");
      lcd.setCursor(9, 1);
      lcd.print(i);
      lcd.setCursor(0, 2);
      lcd.print("CHECKING");

    }


  }
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print("Tall Objects");
  lcd.setCursor(7, 1);
  lcd.print(Tall);
  lcd.setCursor(0, 2);
  lcd.print("Short Objects");
  lcd.setCursor(7, 3);
  lcd.print(Short);
  delay(1000);
  lcd.clear();
  result = false;
  return;
}





void DetectButtons()
{
  lcd.clear(); //Then clean it
  if (key == '*') //If cancel Button is pressed
  {lcd.clear();
    lcd.println ("Button Cancel");
    delay(1000);
    lcd.clear();
    setup();
    return;
    result = false;
  }

  if (key == '1') //If Button 1 is pressed
  { Serial.println ("Button 1");
    if (Number == 0)
      Number = 1;
    else
      Number = (Number * 10) + 1; //Pressed twice
  }

  if (key == '4') //If Button 4 is pressed
  { Serial.println ("Button 4");
    if (Number == 0)
      Number = 4;
    else
      Number = (Number * 10) + 4; //Pressed twice
  }

  if (key == '7') //If Button 7 is pressed
  { Serial.println ("Button 7");
    if (Number == 0)
      Number = 7;
    else
      Number = (Number * 10) + 7; //Pressed twice
  }


  if (key == '0')
  { Serial.println ("Button 0"); //Button 0 is Pressed
    if (Number == 0)
      Number = 0;
    else
      Number = (Number * 10) + 0; //Pressed twice
  }

  if (key == '2') //Button 2 is Pressed
  { Serial.println ("Button 2");
    if (Number == 0)
      Number = 2;
    else
      Number = (Number * 10) + 2; //Pressed twice
  }

  if (key == '5')
  { Serial.println ("Button 5");
    if (Number == 0)
      Number = 5;
    else
      Number = (Number * 10) + 5; //Pressed twice
  }

  if (key == '8')
  { Serial.println ("Button 8");
    if (Number == 0)
      Number = 8;
    else
      Number = (Number * 10) + 8; //Pressed twice
  }


  if (key == '#')
  { Serial.println ("Button Equal");
    lcd.clear();
    result = true;
  }

  if (key == '3')
  { Serial.println ("Button 3");
    if (Number == 0)
      Number = 3;
    else
      Number = (Number * 10) + 3; //Pressed twice
  }

  if (key == '6')
  { Serial.println ("Button 6");
    if (Number == 0)
      Number = 6;
    else
      Number = (Number * 10) + 6; //Pressed twice
  }

  if (key == '9')
  { Serial.println ("Button 9");
    if (Number == 0)
      Number = 9;
    else
      Number = (Number * 10) + 9; //Pressed twice
  }


  lcd.print(Number);
  delay(100);
}











void motoron() {
  pinMode(motorpin, OUTPUT);
  digitalWrite(motorpin, HIGH);

}
void motoroff() {
  pinMode(motorpin, OUTPUT);
  digitalWrite(motorpin, LOW);

}
void input() {}
